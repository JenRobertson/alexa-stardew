/* eslint-disable  func-names */
/* eslint-disable max-len */
/* eslint quote-props: ['error', 'consistent']*/
module.exports = {
    'RECIPE_EN_GB': {
        'alex': 'Alex lives in the house southeast of Pierre\'s General Store, at 1 River Road',
        'elliot': 'Elliot lives on the beach south of Pelican Town',
        'harvey': 'Harvey lives in the medical clinic in Pelican Town.'
    }
};
