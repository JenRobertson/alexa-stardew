/* eslint-disable  func-names */
/* eslint-disable max-len */
/* eslint quote-props: ['error, Rabbit\'s foot and Prismastic Shard', 'consistent']*/
module.exports = {
    'HATES_EN_GB': {
        'alex': 'Alex hates Holly and Quartz, and all Universal Hates.',
        'wlliott': 'Elliot hates Amaranth, Quartz, Salmonberry, Sea Cucumber, and all Universal Hates.',
        'harvey': 'Harvey hates Coral, Nautilus Shells, Rainbow Shells, Salmonberrys, Spice Berrys, and all Universal Hates.',
        'sam': 'Sam hates Coal, Copper Bars, Duck Mayonnaise, Gold Bars, Gold Ore, Iridium Bars, Iridium Ore, Iron Bars, Mayonnaise, Pickles, Refined Quartz, and all Universal Hates.',
        'sebastian': 'Sebastian hates All Artisan Goods (except Coffee, Mead, and Oil), All Eggs (except Void Egg), Clay, Complete Breakfast, Farmer\'s Lunch, Omelet, and all Universal Hates.',
        'shane': 'Shane hates Pickles, Quartz, and all Universal Hates.',
        'abigail': 'Abigail hates Clay, Holly, and all Universal Hates.',
        'emily': 'Emily hates Fish Tacos, Holly, Maki Rolls, Salmon Dinner, Sashimi, and all Universal Hates.',
        'haley': 'All Fish, Clay, Prismatic Shards, Wild Horseradish, and all Universal Hates.',
        'leah': 'Leah hates Bread, Hashbrowns, Pancakes, Pizza, Void Eggs, and all Universal Hates.',
        'maru': 'Maru hates Holly, Honey, Pickles, Snow Yam, Truffles, and all Universal Hates.',
        'penny': 'Penny hates Beer, Grape, Holly, Hops, Mead, Pale Ale, Rabbit\'s Foot, Wine, and all Universal Hates.',
        'caroline': 'Caroline hates Quartz, Salmonberry, and all Universal Hates.',
        'clint': 'Clint hates Holly, and all Universal Hates.',
        'demetrius': 'Demetrius hates Holly, and all Universal Hates.',
        'evelyn': 'Evelyn hates All Fish, Clam, Clay, Coral, Fried Eel, Garlic, Holly, Maki Roll, Salmonberry, Sashimi, Spice Berry, Spicy Eel, Trout Soup, and all Universal Hates.',
        'george': 'George hates Clay, Dandelion, Holly, Quartz, and all Universal Hates.',
        'gus': 'Gus hates Coleslaw, Holly, Quartz, and all Universal Hates.',
        'jas': 'Jas hates All Artisan Goods (except Mead and Oil), Clay, Wild Horseradish, and all Universal Hates.',
        'jodi': 'Jodi hates Daffodils, Dandelions, Spice Berry, and all Universal Hates.',
        'kent': 'Kent hates All Milk, Algae Soup, Holly, Sashimi, Tortilla, and all Universal Hates.',
        'lewis': 'Lewis hates Holly, Quartz, and all Universal Hates.',
        'linus': 'Linus does not hate anything!, and all Universal Hates.',
        'marnie': 'Marnie hates Clay, Holly, and all Universal Hates.',
        'pam': 'Pam hates Holly, Octopus, Squid, and all Universal Hates.',
        'pierre': 'Pierre hates All Fish, Corn, Garlic, Parsnip Soup, Tortilla, and all Universal Hates.',
        'robin': 'Robin hates holly, and all Universal Hates.',
        'vincent': 'Vincent hates All Artisan Goods (except Mead & Oil), Clay, Wild Horseradish, and all Universal Hates.',
        'willy': 'Willy does not hate anything!, and all Universal Hates.',
        'dwarf': 'The Dwarf does not hate anything!, and all Universal Hates.',
        'krobus': 'Krobus does not hate anything!, and all Universal Hates.',
        'sandy': 'Sandy hates holly, and all Universal Hates.',
        'wizard': 'Wizard does not hate anything!, and all Universal Hates.',
        'universal': 'The Universal Hates are All Artifacts, All Bait, All Crafted Artisan Equipment, All Crafted Lighting (except Jack O Lantern which is disliked), All Miscellaneous Crafted Items (except Iron Bar and Gold Bar which are disliked), All Furniture (except Tea Set which is disliked), All Monster Loot (except Solar Essence and Void Essence which are disliked), All Trash (except Driftwood which is disliked), Sap, Carp, Seaweed, Green Algae, White Algae, Grass Starter, Hay, Poppy, Copper Ore, Iron Ore, Sea Urchins, Red Mushrooms, Snail, Oil of Garlic, Strange bun, Void Mayonnaise, Sugar, Teasure Chest, Energy Tonic, Muscle Remedy, Golden Pumpkin, Slime Eggs of all colours and Crab Pots'
    }
};
