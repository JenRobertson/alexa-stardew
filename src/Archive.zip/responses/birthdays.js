/* eslint-disable  func-names */
/* eslint-disable max-len */
/* eslint quote-props: ['error', 'consistent']*/
module.exports = {
    'BIRTHDAYS_EN_GB': {
        'alex': 'Alex\'s birthday is Summer 13',
        'alex\'s': 'Alex\'s birthday is Summer 13',
        'alexs': 'Alex\'s birthday is Summer 13',
        'elliott': 'Elliot\'s birthday is Fall 5',
        'harvey': 'Harvey\'s birthday is Winter 14'
    }
};
