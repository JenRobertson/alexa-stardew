/* eslint-disable  func-names */
/* eslint-disable max-len */
/* eslint quote-props: ['error, Rabbit\'s foot and Prismastic Shard', 'consistent']*/
module.exports = {
    'LOVES_EN_GB': {
        'alex': 'Alex loves Complete Breakfast, Salmon Dinner, Rabbit\'s foot and Prismastic Shard',
        'wlliott': 'Elliot loves Crab Cakes, Duck Feathers, Lobsters, Pomegranates, Tom Kha Soup, Rabbit\'s foot and Prismastic Shard',
        'harvey': 'Harvey loves Coffee, Pickles, Super Meal, Truffle Oil, Wine, Rabbit\'s foot and Prismastic Shard',
        'sam': 'Sam loves Cactus Fruit, Maple Bar, Pizza and Tigerseye, Rabbit\'s foot and Prismastic Shard',
        'sebastian': 'Sebastian loves Frozen Tear, Obsidian, Pumpkin Soup, Sashimi and Void Egg, Rabbit\'s foot and Prismastic Shard',
        'shane': 'Shane loves Hot Peppers, Pepper Poppers, Pizzas, Rabbit\'s foot and Prismastic Shard',
        'abigail': 'Abigail loves Amethyst, Blackberry Cobbler, Chocolate Cake, Pufferfish, Pumpkin, Spicy Eel, Rabbit\'s foot and Prismastic Shard',
        'emily': 'Emily loves Amethyst, Aquamarine, Cloth, Emerald, Jade, Ruby, Survival Burger, Topaz, Wool , Rabbit\'s foot and Prismastic Shard',
        'haley': 'Haley loves Coconut Fruit Salad Pink Cak Sunflower, Rabbit\'s foot and Prismastic Shard',
        'leah': 'Leah loves Goat Cheese, Poppyseed, Muffi Salad ,Stir Fry, Truffle, Vegetable Medle Wine, Rabbit\'s foot and Prismastic Shard',
        'maru': 'Maru loves Battery Packs, Cauliflower Cheese, Cauliflower, Diamond, Gold Bar, Iridium Bar, Mine Miner\'s Treat, Pepper Poppers, Rhubarb Pie, Strawberry, Rabbit\'s foot and Prismastic Shard',
        'penny': 'Penny loves Diamond, Emerald, Melon, Poppy, Poppyseed Muffin, Red Plate, Roots Platter, Sandfish, Tom Kha Soup, Rabbit\'s foot and Prismastic Shard',
        'caroline': 'Caroline loves Fish Taco Summer Spangle, Rabbit\'s foot and Prismastic Shard',
        'clint': 'Clint loves Amethys, Aquamarine, Artichoke Dip, Emerald, Fiddlehead Risotto, Gold Bar, Iridium Bar, Jade, Omni Geode, Ruby, Topaz, Rabbit\'s foot and Prismastic Shard',
        'demetrius': 'Demetrius loves Bean Hotpot, Ice Cream, Rice Pudding, Strawberry, Rabbit\'s foot and Prismastic Shard',
        'evelyn': 'Evelyn loves Beet, Chocolate Cake, Diamonds, Fairy Roses, Stuffing, Tulips, Rabbit\'s foot and Prismastic Shard',
        'george': 'George loves Fried Mushrooms, Leeks, Rabbit\'s foot and Prismastic Shard',
        'gus': 'Gus loves Diamonds, Escargot, Fish Tacos, Oranges, Rabbit\'s foot and Prismastic Shard',
        'jas': 'Jas loves Fairy Rose, Pink Cake, Plum Pudding, Rabbit\'s foot and Prismastic Shard',
        'jodi': 'Jodi loves Chocolate Cake, Crispy Bass, Diamond, Eggplant Parmesan, Fried Eel, Pancakes, Rhubarb Pie, Vegetable Medley, Rabbit\'s foot and Prismastic Shard',
        'kent': 'Kent loves Fiddlehead Risotto, Roasted Hazelnuts, Rabbit\'s foot and Prismastic Shard',
        'lewis': 'Lewis loves Autum Autumn\'s Bounty, Glazed Yams, Hot Peppers, Vegetable Medley, Rabbit\'s foot and Prismastic Shard',
        'linus': 'Linus loves Blueberry Tart, Cactus Fruit, Coconut, Dish o Dish o\' The Sea, Yams, Rabbit\'s foot and Prismastic Shard',
        'marnie': 'Marnie loves Diamonds, Farmer\'s Lunch, Pink Cake, Pumpkin Pie, Rabbit\'s foot and Prismastic Shard',
        'pam': 'Pam loves Beer, Cactus Fruit, Glazed Yam, Mead, Pale Ale, Parsnip, Parsnip Soup, Rabbit\'s foot and Prismastic Shard',
        'pierre': 'Pierre loves Fried Calamari, Rabbit\'s foot and Prismastic Shard',
        'robin': 'Robin loves Goat Cheese, Peaches, Spaghetti, Rabbit\'s foot and Prismastic Shard',
        'vincent': 'Vincent loves Cranberry Candy, Grapes, Pink Cake, Rabbit\'s foot and Prismastic Shard',
        'willy': 'Willy loves Catfish, Diamonds, Iridium Bars, Mead, Octopus, Pumpkins, Sea Cucumbers, Sturgeon, Rabbit\'s foot and Prismastic Shard',
        'dwarf': 'The Dwarf loves Amethys, Aquamarine, Emerald, Jade, Omni Geode, Ruby, Topaz, Rabbit\'s foot and Prismastic Shard',
        'krobus': 'Krobus loves Diamonds, Iridium Bars, Pumpkins, Void Eggs, Void Mayonnaise, Wild Horseradish, Rabbit\'s foot and Prismastic Shard',
        'sandy': 'Sandy loves Crocuses, Daffodils, Sweet Peas, Rabbit\'s foot and Prismastic Shard',
        'wizard': 'Wizard loves Purple Mushrooms, Solar Essence, Super Cucumbers, Void Essence, Rabbit\'s foot and Prismastic Shard',
        'universal': 'The Universal loves are Prismatic Shard and Rabbits foot.'
    }
};
