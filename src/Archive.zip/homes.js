/* eslint-disable  func-names */
/* eslint-disable max-len */
/* eslint quote-props: ['error', 'consistent']*/
module.exports = {
    'HOMES_EN_GB': {
        'apple crumble': 'For an apple crumble you will need: 3 bramley apples, flour, sugar and butter.',
        'brownies': 'To make brownies you need 2 packs of chocolate buttons, oil, flour, and milk.',
        'chocolate brownies': 'To make brownies you need 2 packs of chocolate buttons, oil, flour, and milk.',
        'fish chowder': 'To make fish chowder you need 2 cod fillets, 3 carrots, 2 potatoes, one onion, butter, and milk.',
        'chowder': 'To make fish chowder you need 2 cod fillets, 3 carrots, 2 potatoes, one onion, butter, and milk.',
        'roast': 'To make roast you need a joint of beef or pork, 2 carrots, 2 brocollis, some roast potatoes, gravy granules, and a sachet and milk for bread sauce.',
        'potato and leak soup': 'To make potato and leak soup you need 2 potatoes, 3 leaks, milk, and cream.',
        'rice crispy cake': 'To make a rice crispy cake you need milk chocolate and rice crispies'
    }
};
